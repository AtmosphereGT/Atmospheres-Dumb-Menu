﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class Fly
    {
        public static void SlowMonkeMod()
        {
            GorillaLocomotion.GTPlayer.Instance.maxJumpSpeed = 0.1f;
            GorillaLocomotion.GTPlayer.Instance.jumpMultiplier = 0.1f;
        }
    }
}
