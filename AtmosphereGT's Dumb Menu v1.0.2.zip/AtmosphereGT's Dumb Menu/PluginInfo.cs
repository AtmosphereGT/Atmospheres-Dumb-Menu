﻿namespace StupidTemplate
{
    internal class PluginInfo
    {
        public const string GUID = "org.atmospheregt.gorillatag.menutemplate";
        public const string Name = "AtmosphereGT's Dumb Menu";
        public const string Description = "Created by AtmosphereGT";
        public const string Version = "1.0.2";
    }
}
